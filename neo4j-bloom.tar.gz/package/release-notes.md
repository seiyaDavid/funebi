
## 1.3.1

This release contains the following improvements and bug fixes:

- Generate zip file on csv export - exporting the nodes and relationships as two files didn't work consistently in all web browsers.

- Show a loading spinner while generating perspective

- Remove duplicates in the list of databases when connected to a Neo4j cluster

- Fix bug where properties were missing in some cases for nodes with multiple labels


